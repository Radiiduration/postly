#!/usr/bin/env python3
"""
LinkedIn Autoposter: personal, human-in-the-loop.

Commands
  prompt   Email you a weekly "what's on your mind?" check-in.
  draft    Generate 2 posts + 1 article (from your reply, or from AI/market news
           if you didn't reply) and email you a preview.
  check    Read your email replies (approve / skip / edit), then publish anything
           that is approved and due. Also warns you before the LinkedIn token expires.
  status   Print the current state (local use).

Nothing is ever posted without an explicit "approve" reply from OWNER_EMAIL.
"""
from __future__ import annotations

import argparse
import email
import imaplib
import json
import os
import re
import smtplib
import sys
import uuid
from datetime import date, datetime, timedelta, timezone
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.utils import parseaddr
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

ROOT = Path(__file__).resolve().parent
STATE_PATH = ROOT / "state" / "state.json"


def env(name: str, default: str = "") -> str:
    return os.environ.get(name) or default


def need(name: str) -> str:
    v = os.environ.get(name)
    if not v:
        sys.exit(f"Missing required environment variable: {name}")
    return v


# ----------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------
MODEL = env("ANTHROPIC_MODEL", "claude-sonnet-5-5")
TIMEZONE = env("TIMEZONE", "Australia/Melbourne")
LINKEDIN_VERSION = env("LINKEDIN_VERSION", "202601")  # YYYYMM; bump if LinkedIn sunsets it
DRY_RUN = env("DRY_RUN") == "1"  # log instead of posting to LinkedIn
NO_EMAIL = env("NO_EMAIL") == "1"  # print emails instead of sending (local testing)

DAY = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
MAX_LEN = 2900  # LinkedIn's hard limit is 3000 characters


def parse_slots(raw: str) -> dict[str, tuple[int, str]]:
    out = {}
    for part in raw.split(","):
        k, v = part.strip().split("=")
        d, hm = v.split()
        out[k.strip()] = (DAY[d.lower()[:3]], hm)
    return out


# item id -> (weekday, "HH:MM") in TIMEZONE
SLOTS = parse_slots(env("SLOTS", "1=Tue 09:00,2=Thu 09:00,3=Sat 10:00"))


def slot_label(item_id: str) -> str:
    d, hm = SLOTS[item_id]
    return f"{list(DAY)[d].title()} {hm} ({TIMEZONE})"


# ----------------------------------------------------------------------------
# State
# ----------------------------------------------------------------------------
def load_state() -> dict:
    if STATE_PATH.exists():
        s = json.loads(STATE_PATH.read_text())
    else:
        s = {}
    s.setdefault("batches", {})
    s.setdefault("history", [])
    s.setdefault("inputs", [])
    s.setdefault("last_expiry_warning", None)
    return s


def save_state(s: dict) -> None:
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(json.dumps(s, indent=2, ensure_ascii=False))


def read_file(name: str) -> str:
    p = ROOT / name
    return p.read_text().strip() if p.exists() else ""


# ----------------------------------------------------------------------------
# Email (Gmail via SMTP/IMAP + app password)
# ----------------------------------------------------------------------------
def owner_email() -> str:
    return env("OWNER_EMAIL") or need("GMAIL_ADDRESS")


def send_email(subject: str, body: str) -> None:
    if NO_EMAIL:
        print(f"\n===== EMAIL =====\nSubject: {subject}\n\n{body}\n=================\n")
        return
    msg = EmailMessage()
    msg["From"] = need("GMAIL_ADDRESS")
    msg["To"] = owner_email()
    msg["Subject"] = subject
    msg.set_content(body)
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as s:
        s.login(need("GMAIL_ADDRESS"), need("GMAIL_APP_PASSWORD"))
        s.send_message(msg)


TAG_RE = re.compile(r"\[LP-([bi])-([0-9a-f]{6})\]")


def _body_text(msg: email.message.Message) -> str:
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain" and not part.get_filename():
                return part.get_payload(decode=True).decode(
                    part.get_content_charset() or "utf-8", errors="replace"
                )
        for part in msg.walk():
            if part.get_content_type() == "text/html":
                html = part.get_payload(decode=True).decode(
                    part.get_content_charset() or "utf-8", errors="replace"
                )
                return re.sub(r"<[^>]+>", "", re.sub(r"<br\s*/?>|</p>|</div>", "\n", html))
        return ""
    payload = msg.get_payload(decode=True)
    return payload.decode(msg.get_content_charset() or "utf-8", errors="replace") if payload else ""


def is_valid_owner_reply(msg: email.message.Message, subject: str) -> bool:
    """Only accept real replies from the owner's address that didn't fail SPF/DKIM."""
    sender = parseaddr(msg.get("From", ""))[1].lower()
    if sender != owner_email().lower():
        return False
    if not re.match(r"^\s*(re|aw|sv)\s*:", subject, re.I):
        return False
    auth = " ".join(msg.get_all("Authentication-Results") or []).lower()
    if "dkim=fail" in auth or "spf=fail" in auth:
        return False
    return True


def poll_inbox(handler) -> None:
    """Process valid unread replies. Leave a message unread if processing fails.

    Leaving failures unread is deliberate: it is safer to retry a command than to
    silently lose an approval because Gmail or the model had a transient error.
    """
    if NO_EMAIL:
        print("NO_EMAIL set: skipping inbox polling")
        return
    M = imaplib.IMAP4_SSL("imap.gmail.com")
    M.login(need("GMAIL_ADDRESS"), need("GMAIL_APP_PASSWORD"))
    M.select("INBOX")
    _, data = M.search(None, '(UNSEEN SUBJECT "[LP-")')
    for num in data[0].split():
        handled = False
        try:
            _, d = M.fetch(num, "(BODY.PEEK[])")
            msg = email.message_from_bytes(d[0][1])
            subject = str(make_header(decode_header(msg.get("Subject", ""))))
            m = TAG_RE.search(subject)
            if m and is_valid_owner_reply(msg, subject):
                handler(m.group(1), m.group(2), _body_text(msg))
            handled = True
        except Exception as e:  # never let one bad email block the rest
            print(f"Error handling email {num!r}: {e}", file=sys.stderr)
        finally:
            if handled:
                M.store(num, "+FLAGS", "\\Seen")
    M.logout()


# ----------------------------------------------------------------------------
# Reply parsing
# ----------------------------------------------------------------------------
def clean_reply(text: str) -> str:
    """Keep only what the user typed, dropping quoted history."""
    lines = text.replace("\r\n", "\n").split("\n")
    kept = []
    for i, ln in enumerate(lines):
        s = ln.strip()
        nxt = lines[i + 1].strip() if i + 1 < len(lines) else ""
        if (
            s.startswith(">")
            or re.match(r"^On .+wrote:?$", s)
            or re.match(r"^On .+wrote:?$", f"{s} {nxt}".strip())
            or re.match(r"^-{2,}\s*Original Message", s, re.I)
            or re.match(r"^From:\s", s)
        ):
            break
        kept.append(ln)
    return "\n".join(kept).strip()


_FILLER = {"all", "now", "and", "&", "please", "pls", "thanks", "thx", "thank", "you", "everything"}


def _ids(rest: str) -> list[str] | None:
    """Return item ids named in `rest`, ['all'] if none, or None if ambiguous.

    ``now`` is intentionally accepted here because the caller uses it to make an
    approval publish on the next check.  It used to be rejected despite being
    advertised in every preview email.
    """
    tokens = re.findall(r"[A-Za-z]+|\d", rest.lower())
    ids, other = [], []
    for t in tokens:
        if t in "123" and len(t) == 1:
            ids.append(t)
        elif t not in _FILLER:
            other.append(t)
    if other:
        return None
    return sorted(set(ids)) or ["all"]


def parse_commands(text: str) -> list[dict]:
    """
    Grammar (one command per line):
      approve | approve all | approve 1 3 | approve 2 now
      skip | skip 2
      edit 2: make it shorter
    Lines that don't parse strictly are ignored, so an ambiguous reply never posts.
    """
    cmds = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^(approve[d]?|lgtm|yes|ok)\b[\s:,.!-]*(.*)$", line, re.I)
        if m:
            ids = _ids(m.group(2))
            if ids is not None:
                cmds.append({"action": "approve", "ids": ids, "now": bool(re.search(r"\bnow\b", m.group(2), re.I))})
            continue
        m = re.match(r"^(skip|reject|discard)\b[\s:,.!-]*(.*)$", line, re.I)
        if m:
            ids = _ids(m.group(2))
            if ids is not None:
                cmds.append({"action": "skip", "ids": ids})
            continue
        m = re.match(r"^edit\s*([123])\s*[:\-]?\s*(.+)$", line, re.I)
        if m:
            cmds.append({"action": "edit", "ids": [m.group(1)], "feedback": m.group(2).strip()})
    return cmds


# ----------------------------------------------------------------------------
# Claude
# ----------------------------------------------------------------------------
SYSTEM = """You are the ghostwriter for one person's personal LinkedIn account. Write in first person as them.

HARD RULES
- Never invent personal facts, achievements, numbers, employers or experiences. Use only what appears in PROFILE or THIS WEEK'S INPUT. If you lack a personal angle, write an opinion/analysis piece instead of a fake anecdote.
- Markets: opinion and analysis only. Never tell readers to buy, sell or hold a specific security. Any markets post ends with the line "Just my view, not financial advice."
- Use web search only to verify recent AI or market news. Do not state a news fact you could not verify. Do not paste URLs or citations into the text.
- POST: 600-1400 characters. Strong first line (under 12 words, no clickbait, never "I'm excited to announce"). Short paragraphs. Plain text only (no markdown, no ** or #-headings). At most 1 emoji. At most 3 hashtags, at the very end. Finish with a specific question or a crisp closing line.
- ARTICLE: a long-form LinkedIn post of 1800-2700 characters with a title (max 90 characters). Plain-text paragraphs, one real argument, concrete examples. No markdown symbols.
- Every item must be under 2900 characters including its title.
- Sound like a sharp student-builder talking to peers, not a press release. Avoid: game-changer, unlock, delve, leverage, "in today's fast-paced world".
- Use at least 2 different pillars across the 3 items (ai_take, markets, learning, achievement) and avoid recently covered topics.
- Return ONLY one JSON object. No prose before or after, no code fences."""

SCHEMA = """{
  "items": [
    {"id": "1", "kind": "post",    "pillar": "ai_take|markets|learning|achievement", "topic": "5-10 word summary", "text": "..."},
    {"id": "2", "kind": "post",    "pillar": "...", "topic": "...", "text": "..."},
    {"id": "3", "kind": "article", "pillar": "...", "topic": "...", "title": "...", "text": "..."}
  ]
}"""


def call_claude(system: str, user: str, search: bool = False, max_tokens: int = 4000) -> str:
    import anthropic

    client = anthropic.Anthropic()
    kwargs = dict(model=MODEL, max_tokens=max_tokens, system=system, messages=[{"role": "user", "content": user}])
    if search:
        kwargs["tools"] = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 4}]
    try:
        resp = client.messages.create(**kwargs)
    except anthropic.APIError as e:
        if not search:
            raise
        print(f"Web search failed ({e}); retrying without it", file=sys.stderr)
        kwargs.pop("tools")
        resp = client.messages.create(**kwargs)
    return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")


def extract_json(text: str, must_have: str) -> dict:
    dec = json.JSONDecoder()
    for m in re.finditer(r"\{", text):
        try:
            obj, _ = dec.raw_decode(text[m.start():])
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and must_have in obj:
            return obj
    raise ValueError("No valid JSON found in model output")


def trim_to(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    cut = text[:limit]
    for sep in ("\n\n", ". ", "\n"):
        idx = cut.rfind(sep)
        if idx > limit * 0.6:
            return cut[: idx + (1 if sep == ". " else 0)].rstrip()
    return cut.rstrip()


def full_text(item: dict) -> str:
    if item["kind"] == "article" and item.get("title"):
        return f"{item['title'].strip()}\n\n{item['text'].strip()}"
    return item["text"].strip()


def generate_batch(state: dict, week_input: str | None) -> dict:
    today = datetime.now(ZoneInfo(TIMEZONE)).strftime("%A %d %B %Y")
    hist = "\n".join(f"- {h['date']} [{h['pillar']}] {h['topic']}" for h in state["history"][-20:]) or "(none yet)"
    if week_input:
        mode = (
            "THIS WEEK'S INPUT (the owner's own rough notes, so these are their real experiences and opinions. "
            "Keep their stance and facts; polish the writing; you may search to verify any news they reference):\n"
            + week_input
        )
    else:
        mode = (
            "NO INPUT this week. Use web search to find 2-3 notable AI and stock-market developments from the "
            f"past 7 days (today is {today}) and write analytical takes grounded in them, using the stances in "
            "PROFILE. Do not invent personal experiences. The owner will add their own angle when editing."
        )
    user = f"""Today is {today}.

PROFILE
{read_file('profile.md')}

VOICE SAMPLES AND STYLE NOTES
{read_file('voice.md')}

RECENTLY COVERED (avoid repeating)
{hist}

{mode}

Write 2 posts and 1 article. Output JSON in exactly this shape:
{SCHEMA}"""
    raw = call_claude(SYSTEM, user, search=True, max_tokens=5000)
    data = extract_json(raw, "items")
    items = {}
    for n, it in enumerate(data["items"][:3], start=1):
        kind = "article" if n == 3 else "post"
        item = {
            "kind": kind,
            "pillar": it.get("pillar", "ai_take"),
            "topic": it.get("topic", "")[:120],
            "title": it.get("title") if kind == "article" else None,
            "text": it["text"].strip(),
            "status": "pending",
            "publish_at": None,
            "linkedin_id": None,
            "error": None,
        }
        title_len = len(item["title"] or "") + 2 if item["title"] else 0
        item["text"] = trim_to(item["text"], MAX_LEN - title_len)
        items[str(n)] = item
    if len(items) != 3:
        raise ValueError(f"Model returned {len(items)} items, expected 3")
    return {
        "created": datetime.now(timezone.utc).isoformat(),
        "mode": "input" if week_input else "news",
        "items": items,
    }


def regenerate_item(item: dict, feedback: str) -> None:
    user = f"""Revise this LinkedIn {item['kind']} following the feedback. Keep every hard rule.

CURRENT VERSION
{full_text(item)}

FEEDBACK FROM THE OWNER
{feedback}

PROFILE
{read_file('profile.md')}

VOICE SAMPLES AND STYLE NOTES
{read_file('voice.md')}

Return ONLY JSON: {{"title": {'"..."' if item['kind'] == 'article' else 'null'}, "text": "..."}}"""
    raw = call_claude(SYSTEM, user, search=False, max_tokens=3000)
    data = extract_json(raw, "text")
    if item["kind"] == "article" and data.get("title"):
        item["title"] = data["title"].strip()
    title_len = len(item["title"] or "") + 2 if item["title"] else 0
    item["text"] = trim_to(data["text"].strip(), MAX_LEN - title_len)


# ----------------------------------------------------------------------------
# LinkedIn
# ----------------------------------------------------------------------------
_RESERVED = re.compile(r"([\\|{}@\[\]()<>*_~])")


def escape_commentary(text: str) -> str:
    """LinkedIn's 'little text' format treats these characters specially. '#' is left alone so hashtags work."""
    return _RESERVED.sub(r"\\\1", text)


def publish_linkedin(text: str) -> str:
    if DRY_RUN:
        print(f"[DRY_RUN] would post to LinkedIn:\n{text}\n")
        return "urn:li:share:DRYRUN"
    body = {
        "author": f"urn:li:person:{need('LINKEDIN_PERSON_ID')}",
        "commentary": escape_commentary(text),
        "visibility": "PUBLIC",
        "distribution": {
            "feedDistribution": "MAIN_FEED",
            "targetEntities": [],
            "thirdPartyDistributionChannels": [],
        },
        "lifecycleState": "PUBLISHED",
        "isReshareDisabledByAuthor": False,
    }
    r = requests.post(
        "https://api.linkedin.com/rest/posts",
        headers={
            "Authorization": f"Bearer {need('LINKEDIN_ACCESS_TOKEN')}",
            "Linkedin-Version": LINKEDIN_VERSION,
            "X-Restli-Protocol-Version": "2.0.0",
            "Content-Type": "application/json",
        },
        json=body,
        timeout=30,
    )
    if r.status_code != 201:
        raise RuntimeError(f"LinkedIn API {r.status_code}: {r.text[:500]}")
    return r.headers.get("x-restli-id", "unknown")


def next_slot(item_id: str) -> str:
    tz = ZoneInfo(TIMEZONE)
    now = datetime.now(tz)
    wd, hm = SLOTS[item_id]
    h, m = map(int, hm.split(":"))
    cand = (now + timedelta(days=(wd - now.weekday()) % 7)).replace(hour=h, minute=m, second=0, microsecond=0)
    if cand <= now:
        cand += timedelta(days=7)
    return cand.astimezone(timezone.utc).isoformat()


# ----------------------------------------------------------------------------
# Email rendering
# ----------------------------------------------------------------------------
HELP = """Reply to this email with one command per line:
  approve            approve everything (posts go out at the scheduled slots)
  approve 1 3        approve only items 1 and 3
  approve 2 now      approve item 2 and post it at the next check (within the hour)
  skip 2             discard item 2
  edit 2: make it shorter and less salesy

Nothing is posted until you approve."""


def render_items(batch: dict, ids: list[str] | None = None) -> str:
    out = []
    for i, item in batch["items"].items():
        if ids and i not in ids:
            continue
        label = "ARTICLE (long-form post)" if item["kind"] == "article" else "POST"
        out.append(
            f"[{i}] {label}  |  {item['pillar']}  |  planned: {slot_label(i)}  |  status: {item['status']}\n"
            f"{'-' * 60}\n{full_text(item)}\n{'-' * 60}  ({len(full_text(item))} chars)\n"
        )
    return "\n".join(out)


# ----------------------------------------------------------------------------
# Commands
# ----------------------------------------------------------------------------
def cmd_prompt(state: dict) -> None:
    iid = uuid.uuid4().hex[:6]
    for old in state["inputs"]:
        old["stale"] = True
    state["inputs"].append({"id": iid, "sent": datetime.now(timezone.utc).isoformat(), "reply": None, "used": False})
    state["inputs"] = state["inputs"][-8:]
    send_email(
        f"[LP-i-{iid}] Weekly check-in: what's on your mind?",
        "Reply with rough bullets, anything counts:\n"
        "  - something you built, learned or finished this week\n"
        "  - a take on AI news\n"
        "  - a market move you have an opinion on\n"
        "  - a win, big or small\n\n"
        "Typos are fine. If you skip this, I'll draft from this week's AI and market news instead "
        "and you can edit it.",
    )


def cmd_draft(state: dict) -> None:
    inp = next((x for x in reversed(state["inputs"]) if x.get("reply") and not x.get("used")), None)
    batch = generate_batch(state, inp["reply"] if inp else None)
    bid = uuid.uuid4().hex[:6]
    today = datetime.now(ZoneInfo(TIMEZONE)).strftime("%Y-%m-%d")
    note = (
        "Built from your check-in reply."
        if inp
        else "No check-in reply this week, so these are drafted from AI/market news. Add your own angle with 'edit N: ...'."
    )
    send_email(
        f"[LP-b-{bid}] Preview: 2 posts + 1 article. Reply \"approve\" to schedule",
        f"{note}\n\n{render_items(batch)}\n{HELP}",
    )
    # Do not create an unreachable batch if sending the preview failed.
    if inp:
        inp["used"] = True
    state["batches"][bid] = batch
    for item in batch["items"].values():
        state["history"].append({"date": today, "pillar": item["pillar"], "topic": item["topic"]})
    state["history"] = state["history"][-60:]
    # Retain active work even if the archive grows beyond the normal window.
    completed = [k for k, b in state["batches"].items() if all(i["status"] in {"published", "skipped", "failed"} for i in b["items"].values())]
    for k in completed[:-12]:
        del state["batches"][k]


def handle_input_reply(state: dict, iid: str, body: str) -> None:
    for x in state["inputs"]:
        if x["id"] == iid:
            text = clean_reply(body)
            if text:
                x["reply"] = (x["reply"] + "\n" + text) if x.get("reply") else text
                send_email(f"[LP-i-{iid}] Got it", "Thanks, I'll use this in the next drafting run.")
            return


def handle_batch_reply(state: dict, bid: str, body: str) -> None:
    batch = state["batches"].get(bid)
    if not batch:
        send_email(f"[LP-b-{bid}] Unknown batch", "I no longer have that batch in my state.")
        return
    cmds = parse_commands(clean_reply(body))
    if not cmds:
        send_email(
            f"[LP-b-{bid}] I didn't understand that (nothing was changed)",
            "I only act on exact commands so nothing posts by accident.\n\n" + HELP,
        )
        return
    notes, edited = [], []
    for c in cmds:
        ids = list(batch["items"]) if c["ids"] == ["all"] else c["ids"]
        for i in ids:
            item = batch["items"].get(i)
            if not item:
                continue
            if item["status"] == "published":
                notes.append(f"[{i}] already published, left unchanged")
            elif c["action"] == "approve":
                item["status"] = "approved"
                item["publish_at"] = datetime.now(timezone.utc).isoformat() if c.get("now") else next_slot(i)
                item["error"] = None
                when = "at the next check" if c.get("now") else slot_label(i)
                notes.append(f"[{i}] approved, will post {when}")
            elif c["action"] == "skip":
                item["status"] = "skipped"
                notes.append(f"[{i}] skipped")
            elif c["action"] == "edit":
                try:
                    regenerate_item(item, c["feedback"])
                    item["status"] = "pending"
                    item["publish_at"] = None
                    edited.append(i)
                    notes.append(f"[{i}] revised, needs your approval again")
                except Exception as e:
                    notes.append(f"[{i}] edit failed: {e}")
    body_out = "\n".join(notes)
    if edited:
        body_out += "\n\nRevised drafts:\n\n" + render_items(batch, edited) + "\n" + HELP
    send_email(f"[LP-b-{bid}] Update", body_out)


def publish_due(state: dict) -> None:
    now = datetime.now(timezone.utc)
    for bid, batch in state["batches"].items():
        for i, item in batch["items"].items():
            if item["status"] != "approved" or not item.get("publish_at"):
                continue
            if datetime.fromisoformat(item["publish_at"]) > now:
                continue
            try:
                urn = publish_linkedin(full_text(item))
                item["status"], item["linkedin_id"] = "published", urn
                item["published_at"] = now.isoformat()
                send_email(
                    f"[LP-b-{bid}] Posted: item {i}",
                    f"Published to LinkedIn.\nhttps://www.linkedin.com/feed/update/{urn}\n\n{full_text(item)}",
                )
            except Exception as e:
                item["status"], item["error"] = "failed", str(e)
                send_email(
                    f"[LP-b-{bid}] FAILED to post item {i}",
                    f"{e}\n\nReply 'approve {i} now' to retry once the problem is fixed.",
                )


def check_token_expiry(state: dict) -> None:
    exp = env("LINKEDIN_TOKEN_EXPIRES")
    if not exp:
        return
    days_left = (date.fromisoformat(exp) - date.today()).days
    if days_left <= 7 and state.get("last_expiry_warning") != date.today().isoformat():
        state["last_expiry_warning"] = date.today().isoformat()
        send_email(
            "LinkedIn token expires soon" if days_left >= 0 else "LinkedIn token EXPIRED",
            f"Your LinkedIn access token expires on {exp} ({days_left} days). "
            "Run `python linkedin_auth.py` locally and update the LINKEDIN_ACCESS_TOKEN and "
            "LINKEDIN_TOKEN_EXPIRES secrets.",
        )


def cmd_check(state: dict) -> None:
    check_token_expiry(state)

    def handler(kind: str, tag: str, body: str) -> None:
        (handle_input_reply if kind == "i" else handle_batch_reply)(state, tag, body)

    poll_inbox(handler)
    publish_due(state)


def cmd_status(state: dict) -> None:
    for bid, b in state["batches"].items():
        print(f"batch {bid} ({b['created'][:10]}, {b['mode']})")
        for i, it in b["items"].items():
            print(f"  [{i}] {it['kind']:7} {it['status']:9} {it['topic']}")


def main() -> None:
    global NO_EMAIL
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["prompt", "draft", "check", "status"])
    ap.add_argument("--no-email", action="store_true", help="print emails instead of sending (local testing)")
    args = ap.parse_args()
    NO_EMAIL = NO_EMAIL or args.no_email
    state = load_state()
    try:
        {"prompt": cmd_prompt, "draft": cmd_draft, "check": cmd_check, "status": cmd_status}[args.command](state)
    finally:
        save_state(state)


if __name__ == "__main__":
    main()
