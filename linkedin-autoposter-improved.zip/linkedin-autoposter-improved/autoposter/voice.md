# VOICE (paste 5-10 of your own posts or writing samples below)

## Style notes
- Direct, curious, a bit informal. Short sentences. No corporate buzzwords.
- First line should make a peer want to click "see more".
- I prefer concrete details over vague claims.
- <add your own: e.g. "dry humour is fine", "never use rhetorical questions in the opener">

## Samples
### Sample 1
<paste a post you wrote>

### Sample 2
<paste another>
