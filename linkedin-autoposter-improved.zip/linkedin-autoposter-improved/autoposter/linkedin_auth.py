#!/usr/bin/env python3
"""
One-time (and every ~60 days) LinkedIn OAuth helper. Run this LOCALLY.

Prereqs: a LinkedIn developer app with these products enabled:
  - "Share on LinkedIn"
  - "Sign In with LinkedIn using OpenID Connect"
and http://localhost:8080/callback added under Auth > Authorized redirect URLs.

  export LINKEDIN_CLIENT_ID=...
  export LINKEDIN_CLIENT_SECRET=...
  python linkedin_auth.py

It prints the values to store as GitHub secrets.
"""
import http.server
import os
import secrets
import sys
import urllib.parse
import webbrowser
from datetime import date, timedelta

import requests

CLIENT_ID = os.environ.get("LINKEDIN_CLIENT_ID") or sys.exit("Set LINKEDIN_CLIENT_ID")
CLIENT_SECRET = os.environ.get("LINKEDIN_CLIENT_SECRET") or sys.exit("Set LINKEDIN_CLIENT_SECRET")
REDIRECT = "http://localhost:8080/callback"
SCOPE = "openid profile w_member_social"
STATE = secrets.token_urlsafe(16)

result = {}


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        if q.get("state", [""])[0] != STATE:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"State mismatch")
            return
        result["code"] = q.get("code", [""])[0]
        result["error"] = q.get("error_description", [""])[0]
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"Done. You can close this tab and return to the terminal.")

    def log_message(self, *a):
        pass


url = "https://www.linkedin.com/oauth/v2/authorization?" + urllib.parse.urlencode(
    {"response_type": "code", "client_id": CLIENT_ID, "redirect_uri": REDIRECT, "state": STATE, "scope": SCOPE}
)
print("Opening browser to authorize...\nIf it doesn't open, visit:\n" + url)
webbrowser.open(url)

server = http.server.HTTPServer(("localhost", 8080), Handler)
while "code" not in result:
    server.handle_request()
if not result["code"]:
    sys.exit(f"Authorization failed: {result['error']}")

tok = requests.post(
    "https://www.linkedin.com/oauth/v2/accessToken",
    data={
        "grant_type": "authorization_code",
        "code": result["code"],
        "redirect_uri": REDIRECT,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
    },
    timeout=30,
)
tok.raise_for_status()
t = tok.json()
info = requests.get(
    "https://api.linkedin.com/v2/userinfo", headers={"Authorization": f"Bearer {t['access_token']}"}, timeout=30
)
info.raise_for_status()
expires = date.today() + timedelta(seconds=int(t.get("expires_in", 5184000)))

print("\nStore these as GitHub repository secrets (and in .env for local runs):\n")
print(f"LINKEDIN_ACCESS_TOKEN={t['access_token']}")
print(f"LINKEDIN_PERSON_ID={info.json()['sub']}")
print(f"LINKEDIN_TOKEN_EXPIRES={expires.isoformat()}")
