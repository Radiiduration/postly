# PROFILE (edit this: the more specific and honest it is, the better the posts)

## Who I am
- Rishi, student at Monash University (Clayton), independent software builder.
- <add: what you're studying, where you're headed, what you want to be known for>

## What I've built / achieved (the ONLY personal facts the AI may use)
- <e.g. FinovaAI: multi-broker fintech platform, what it does, what you learned>
- <e.g. STRYDE: iOS health app prototype>
- <e.g. NatyaShastra: school management platform for a dance academy>
- <add real milestones, numbers, results you're happy to make public>

## Topics I want to be known for
- AI: building with it, where models and tools are heading, practical takes
- Stock markets: how I read markets, AI's impact on them (opinion only, no tips)
- Learning in public: what I'm studying, mistakes, what worked

## My actual stances (opinions the AI should lean on when there's no weekly input)
- <e.g. "Most AI wrapper startups will be commoditised; distribution and data matter more">
- <e.g. "I think about markets in terms of ... ">
- <e.g. "Learning by shipping beats courses">

## Audience
- <e.g. students, early-career engineers, founders, recruiters in AU/India>

## Never mention
- <anything private: family, marks, employer names you don't want public, etc.>
