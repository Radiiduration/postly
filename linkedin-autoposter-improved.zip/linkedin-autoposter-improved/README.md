# LinkedIn Autoposter (personal, approval-first)

This is a small, approval-first LinkedIn writing assistant. It asks what you
want to say, produces a weekly preview, and posts only when you reply with an
explicit approval. It is designed for your own account—not bulk outreach,
browser automation, or scraping.

## What was improved

- `approve 2 now` now works as documented (previously it was accidentally
  rejected by the strict command parser).
- If processing an email reply fails, the message stays unread so it can be
  retried rather than being silently lost.
- A draft batch is saved only after its preview has been sent, avoiding drafts
  that cannot be approved because their email never arrived.
- Cleanup retains active batches; an older pending/approved item is never
  deleted just because newer batches exist.

## Quick start

1. **Unzip or clone this folder into a private GitHub repository.** Keep it
   private: the workflow writes your content history into `state/state.json`.
2. **Create a LinkedIn developer app** and enable the products named below.
   Associate the redirect URL `http://localhost:8080/callback`.
3. **Set up a Python environment locally:**

   ```bash
   cd autoposter
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

4. **Copy the example environment file** and fill in local test values:

   ```bash
   cp .env.example .env
   ```

   Your shell does not automatically load `.env`; either export its values or
   use a dotenv loader. Never commit `.env`.
5. **Personalise `profile.md` and `voice.md`.** Start with 3–5 true facts,
   your audience, two genuine opinions, and a couple of writing samples. These
   files determine whether the drafts sound like you.
6. **Run a harmless local preview:**

   ```bash
   export ANTHROPIC_API_KEY=...
   NO_EMAIL=1 python autoposter.py draft --no-email
   ```

   This generates content and prints the email preview. It does not send an
   email or publish a post. It does update `state/state.json`, so delete that
   test state before your first real run if you want a clean history.
7. **Obtain LinkedIn credentials locally** with `python linkedin_auth.py`,
   then put its three printed values into GitHub Actions secrets. Add the Gmail
   and Anthropic secrets too. Finally run `prompt`, then `draft`, from the
   Actions page to test the end-to-end email flow.

## A simple weekly routine

1. Reply to Friday's check-in with rough bullets.
2. Read Monday's preview. Change it with `edit 1: ...` if it needs your voice.
3. Reply `approve 1 3`, `skip 2`, or `approve 2 now`.
4. The hourly workflow processes the reply and publishes only approved items.

Use `status` from the workflow dispatch menu to see current batches. If
anything looks wrong, use `skip N`; unpublished items are never posted without
an approval.

## Before going live

- Test Gmail delivery and replies with a single draft.
- Confirm the LinkedIn app is approved for your account and that a dry-run
  works: `DRY_RUN=1 python autoposter.py check`.
- Check the cron comments against daylight-saving changes. GitHub schedules
  use UTC; `TIMEZONE` changes labels and slot calculations but not the cron.
- Treat every generated draft as a first draft. Verify personal claims, news,
  market statements, and tone before approving.

---

Every week: it emails you a check-in, drafts **2 posts + 1 article** (AI takes, markets, learning, achievements), emails you a preview, and only posts after you **reply "approve"**.

```
Fri    check-in email  ->  you reply with rough bullets (optional)
Mon    drafts generated ->  preview email
you    reply "approve" / "approve 1 3" / "skip 2" / "edit 2: shorter"
Tue/Thu/Sat  approved items post at their slots (hourly job publishes what's due)
```

No reply to the check-in? It drafts from that week's AI + market news and you can add your angle with `edit N: ...`.

## Reply commands (one per line)
| Reply | Effect |
|---|---|
| `approve` | approve all three, post at their slots |
| `approve 1 3` | approve only those |
| `approve 2 now` | post item 2 at the next hourly check |
| `skip 2` | discard item 2 |
| `edit 2: less salesy, add a number` | rewrite item 2, then it needs approval again |

Anything ambiguous (e.g. "ok but tweak 2") is ignored and you get a help email, so nothing posts by accident. Only replies from `OWNER_EMAIL` that pass SPF/DKIM are accepted.

## Setup (about 20 minutes)

1. **Private GitHub repo.** Push this folder to it (the bot commits `autoposter/state/state.json` back to the repo).
2. **LinkedIn app.** At https://www.linkedin.com/developers/apps create an app (needs a Company Page to associate; any page works). Under *Products* add **Share on LinkedIn** and **Sign In with LinkedIn using OpenID Connect**. Under *Auth* add redirect URL `http://localhost:8080/callback`.
3. **Get your token (local):**
   ```bash
   cd autoposter && pip install -r requirements.txt
   export LINKEDIN_CLIENT_ID=... LINKEDIN_CLIENT_SECRET=...
   python linkedin_auth.py
   ```
   It prints `LINKEDIN_ACCESS_TOKEN`, `LINKEDIN_PERSON_ID`, `LINKEDIN_TOKEN_EXPIRES`. Tokens last ~60 days; the bot emails you a week before expiry, then you rerun this.
4. **Gmail app password.** Turn on 2-Step Verification, then Google Account > Security > App passwords.
5. **GitHub secrets** (Settings > Secrets and variables > Actions): `ANTHROPIC_API_KEY`, `GMAIL_ADDRESS`, `GMAIL_APP_PASSWORD`, `LINKEDIN_ACCESS_TOKEN`, `LINKEDIN_PERSON_ID`, `LINKEDIN_TOKEN_EXPIRES`, optional `OWNER_EMAIL`. Optional **variables**: `TIMEZONE`, `SLOTS`, `ANTHROPIC_MODEL`, `LINKEDIN_VERSION`.
6. **Edit `autoposter/profile.md` and `autoposter/voice.md`.** This is the biggest lever for quality: real achievements, real stances, 5-10 of your own writing samples. The AI is forbidden from inventing personal facts, so anything not in these files or your weekly reply won't be claimed.
7. **Test locally (nothing sent or posted):**
   ```bash
   export ANTHROPIC_API_KEY=...
   python autoposter.py draft --no-email      # prints the preview
   DRY_RUN=1 python autoposter.py check       # logs instead of posting
   ```
8. **Go live:** Actions tab > *autoposter* > Run workflow > `prompt`. Reply to the email, then run `draft`. After that the schedule takes over.

## Things to know
- **Articles:** LinkedIn's public API can't publish native LinkedIn Articles, so the "article" is posted as a long-form post (up to ~2,900 chars) with a title line.
- **Markets content** is opinion only, always ends with a not-financial-advice line, and never names a security to buy/sell.
- **Schedule times** in the workflow are UTC. The defaults assume Melbourne (AEDT, UTC+11). Adjust the cron lines and the `TIMEZONE` / `SLOTS` variables if you want different times.
- **LinkedIn API version:** `LINKEDIN_VERSION` defaults to `202601`. If posting returns a "version not active" error, set the variable to a newer `YYYYMM`.
- **Terms of service:** this uses LinkedIn's official API with your own authorized account and a human approval step. Don't swap it for browser automation or scraping.
- **Hourly latency:** replies are processed at the next hourly run. Use *Run workflow > check* to process immediately.
- Failed posts are never retried automatically (to avoid duplicates); reply `approve N now` to retry.
