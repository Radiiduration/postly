# Style Spec — LinkedIn Autoposter approval-first demo

## Creative north star

Make this feel like a small, trustworthy operating system for one person's professional voice: the automation handles the boring loop, while the owner visibly retains the final publishing decision. The mood is premium, calm, and precise—not a flashy "AI magic" montage and not a literal LinkedIn clone.

There is no reference video. This spec adapts the studio aesthetic baseline for a silent, fictional UI walkthrough.

## Delivery frame

- **Canvas:** 1080 × 1920, vertical 9:16, 30 fps.
- **Duration:** 24 seconds. Silent by design; all meaning must survive muted autoplay.
- **Export intent:** H.264 High / yuv420p, 12–20 Mbps, `+faststart`; no audio track is required. If a silent audio bed is technically needed, use silent AAC 48 kHz.
- **Safe area:** main copy and UI actions live between y=250–1410, x=70–1010. Keep the top 12% and bottom 25% clear. Nothing important under the Reels caption/control area.
- **Readability:** UI labels at least 30 px at final canvas; narrative headlines 76–104 px. Maximum two lines for a title and one action per focal frame.

## Visual system

### Palette

- Base background: `#090D16` (near-black midnight).
- Raised panels: `#111827`, with a thin 1 px border `#253148` at 65% opacity.
- Primary text: `#F7F9FC`; secondary: `#A9B6CA`.
- Trust/accent blue: `#3D8BFF`; pale blue surfaces: `#DCEBFF` (sparingly, only for active/approved states).
- Approval green: `#36C98A`; skip/neutral amber: `#F2B84B`.
- Email paper card: `#F7F8FA` with `#162033` copy, used only when the email needs immediate contrast.

Blue is an interface accent, not an official LinkedIn colour claim. Do not use LinkedIn logos, trademarked UI chrome, or a simulated official inbox.

### Type and UI

- Use **Inter** (or system sans fallback) throughout: 800/700 for headlines, 600 for controls, 450/500 for body. One font family only.
- Headline casing: sentence case. UI labels: normal title/sentence case. Avoid all-caps except compact status chips.
- Build a fictional product shell: 18 px rounded panels, 14 px inner cards, 1 px hairline borders, 18–28 px internal padding, soft black drop shadows. Leave generous empty space.
- Use fictional identity/data consistently: `Rishi I.`, `rishi@example.com`, `Weekly LinkedIn check-in`, draft titles such as “A lesson from simplifying my workflow.”

### Finish

- Crisp UI, controlled contrast, and clean blacks. Very light radial blue glow behind the active module; no heavy gradient fog.
- Optional 2–3% fine grain/vignette only over the global background, never enough to compromise small text.
- No stock footage, no talking head, no simulated typing blocks that make it feel like a hacker demo.

## Motion language

- Every beat has motion: a 1.02–1.05 scale drift on the product canvas, cursor travel, scrolling, field focus, or a masked panel transition. No static frame exceeds one second.
- Entrances: 10–16 frame spring/ease-out with a 10–18 px vertical rise and 2–4 px blur resolving to zero. Exits: 8–12 frame ease-in, with a masked slide rather than a plain fade.
- Use cubic-bezier/spring curves only; stagger related elements 2–4 frames. Cursor clicks have a brief 18 px blue ring and a 2-frame compression on the target.
- Transitions are directional and semantic: inbox card slides up to imply incoming message; draft cards fan/stack; approval command moves along a route into a green gate; final post lifts into view. Avoid default crossfades and unnecessary whip effects.
- Maintain a single virtual camera: subtle 1.03 push-ins at important decisions, then pull back at the final proof. Add restrained shadow parallax to surfaces for depth.

## Screen-by-screen language

| Time | Purpose | Visual treatment | On-screen copy |
|---|---|---|---|
| 0.0–1.5 | Hook | Immediate blue focus pulse around an approval gate; headline snaps in at 0.2 s. | **Your LinkedIn. Your final say.** |
| 1.5–4.5 | Check-in | Product dashboard slides up; weekly check-in email card arrives with cursor-driven “Reply” action. | `Monday, 9:00 AM` / `What did you learn this week?` |
| 4.5–8.0 | Owner input | Bright email-reply card expands; three short rough-note pills land one after another. | `Launched a cleaner workflow` / `Saved 4 hrs/week` / `Lesson: simplify first` |
| 8.0–12.0 | Draft generation | Reply folds into dashboard; three draft-option cards stack in, with the selected option expanding. | **3 drafts, your voice** / `Option 2 · Practical takeaway` |
| 12.0–16.5 | Approval gate | Email command card enters: `approve 2 now`; its route animates into a green “Approval required” gate, which unlocks. | **Nothing posts without you.** / `approve 2 now` |
| 16.5–20.5 | Scheduling | Clean schedule tile expands with date/time and a small status progression (Approved → Scheduled). | `Thursday · 8:15 AM` / `Scheduled` |
| 20.5–24.0 | Published proof / loop | Fictional social-post card rises into a dark feed surface; green published chip resolves, then the approval-gate outline subtly echoes the opening composition. | **Published—only after approval.** / `Your voice, on your terms.` |

## Editorial rhythm

- Open fast: headline is visible by frame 6 and the gate motion starts on frame 1.
- Use 1.5–4 second sections, not a static linear walkthrough. The 12–16.5 second approval moment is the intentional emotional peak and may hold one extra beat for comprehension.
- Keep each screen to one idea. Do not show code, tokens, configuration values, browser chrome, terminal windows, or any real account data.
- The ending must feel like proof, not a promise: the published card is clearly preceded by the visible approval command. Hold its final state long enough to read, then echo the opening gate geometry to make the ending loop-friendly.

## Mandatory visual proof points

1. A weekly email check-in is sent by the tool.
2. The owner replies with rough source notes.
3. The system produces multiple draft choices.
4. The exact explicit command `approve 2 now` is shown and visibly unlocks the path.
5. An approved draft becomes scheduled, then published.

Never imply autonomous posting. Keep “Approval required” or the explicit command visible at the decision moment, and use fictional content throughout.

## Accessibility and risk controls

- High contrast text (target WCAG-like readability); do not use blue text on dark surfaces for essential content without a light backing.
- Redundant state cues: colour + icon + words for Approved, Scheduled, and Published.
- Avoid unreadably small email text: show only the subject, sender context, and 2–3 concise reply notes; crop the rest deliberately.
- Make the mock nature legible through generic product styling and fictional data; do not represent the animation as the actual LinkedIn website or Gmail UI.

## Cover frame

Use the opening approval-gate composition at approximately 0.7 s: dark product canvas, blue gate outline, headline **“Your LinkedIn. Your final say.”** centered in the safe crop. No tiny interface copy should be required to understand it.
