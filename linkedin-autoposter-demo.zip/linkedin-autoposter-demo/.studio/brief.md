# LinkedIn Autoposter — Demo Video Brief

- **Audience:** Rishi and potential users evaluating the tool.
- **Format:** 9:16 product walkthrough, 24 seconds, muted-readable.
- **Story:** The bot sends a weekly check-in; the owner replies with rough notes; it drafts options; the owner explicitly approves; only then is a post published.
- **Visual approach:** A clean dark product-demo interface, using fictional data. LinkedIn blue is an accent only; no claim of official LinkedIn endorsement.
- **Must show:** approval-first gate, email commands, scheduling, and the published result.
- **Assumptions:** No user footage, logo, voiceover, or licensed soundtrack was provided, so this is an animated silent mock walkthrough with light generated UI sounds omitted.
