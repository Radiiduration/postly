# LinkedIn Autoposter — 24-second UI-demo shot list

**Format:** 1080 x 1920, 9:16, 30 fps. Dark, premium fictional product UI; electric blue is reserved for positive system state and the LinkedIn destination. No external LinkedIn logo beyond a small destination label; no implication of endorsement. This is designed to read without audio.

**Continuity:** Use fictional creator **Rishi Patel**, recipient `rishi@studio.example`, and a fictional post. Keep the working canvas within 64 px side margins, below y=230 and above y=1440 (clear of the platform chrome). Maintain a subtle drifting grain, animated cursor, and/or 1–2% camera push in every beat—no static hold over one second. Each entrance uses eased spring/Bezier motion, 2–4 frame staggers, and brief motion blur on panel transitions.

| Time | Duration | Picture / motion | On-screen copy (exact) | Narrative job / transition |
|---|---:|---|---|---|
| 00:00–00:01.50 | 1.50 s | Start on a cropped published-post card that slides down and locks behind a bright approval shield. Camera pushes 104% → 109%. A blue approval check draws on. | **YOU STAY IN CONTROL**<br>Post only after approval | Hook: establishes the approval-first promise on frame 1. Shield becomes a masked wipe into the app inbox. |
| 00:01.50–00:03.40 | 1.90 s | `Autoposter` dashboard comes into focus. The “Weekly check-in” automation pulses once; an email card flies rightward toward an inbox icon. | WEEKLY CHECK-IN<br>What should we share this week? | Explain trigger. Use a short blue trajectory line to lead the eye into the email scene. |
| 00:03.40–00:05.60 | 2.20 s | Faux email client in a floating rounded window. Sender is **Autoposter**; body types in line-by-line. Cursor blinks; reply button rises. | From: Autoposter<br>**What should we share this week?**<br>Reply with rough notes. | Make it clear the system prompts the owner rather than inventing a post unprompted. Swipe the email header left to reveal reply composer. |
| 00:05.60–00:07.80 | 2.20 s | Owner reply types quickly, with 3 staggered bullet cards: “shipped analytics,” “learnt from beta users,” “keep it honest.” Send icon receives an eased press. | Re: Weekly check-in<br>• Shipped analytics<br>• Beta users shaped it<br>• Keep it honest | Demonstrate low-effort email input. The sent envelope compresses into a small AI sparkle, match-cut to drafts. |
| 00:07.80–00:10.30 | 2.50 s | Three draft cards fan outward with a 3D parallax tilt. Labels A / B / C land sequentially; Draft B grows slightly and gets a blue outline. | **AI TURNS NOTES INTO OPTIONS**<br>3 draft directions | The AI step is visible, but cards remain visibly labelled “DRAFT” to avoid suggesting auto-posting. Cards stack into the selected draft. |
| 00:10.30–00:12.60 | 2.30 s | Selected draft opens. Highlighted sentence resolves from placeholder shimmer into readable copy while the status chip stays amber **Needs approval**. | DRAFT B · Needs approval<br>“We shipped analytics because beta users asked…” | Make draft review tangible. Amber status chip expands vertically into an approval command sheet. |
| 00:12.60–00:14.60 | 2.00 s | Email approval card drops in; keyboard types the exact command `approve 2 fri 9am`. The message receives a brief green sent tick. | **EXPLICIT APPROVAL REQUIRED**<br>`approve 2 fri 9am` | Core gate. No implied click-through or automatic publication. Type lands character-by-character, with “approve” highlighted blue. Envelope launches toward scheduling timeline. |
| 00:14.60–00:17.20 | 2.60 s | Schedule timeline slides up from bottom: Friday, 9:00 AM. Draft B card snaps to the timeslot; status changes from amber to blue “Scheduled.” Tiny clock hand moves. | SCHEDULED<br>Fri · 9:00 AM<br>Approval saved | Explain command-driven scheduling. Timeline sweeps forward via fast clock hand and horizontal light streak. |
| 00:17.20–00:19.30 | 2.10 s | At 9:00 AM, schedule card has a measured 0.5s hold, then a blue route animates from Autoposter to a generic “LinkedIn” destination card. | **PUBLISHES AT THE APPROVED TIME**<br>LinkedIn destination | Clarify no post happens before the owner’s chosen time. Destination card unfolds into the public post. |
| 00:19.30–00:21.70 | 2.40 s | Polished published-post mock expands with author Rishi Patel, post excerpt and engagement placeholders. Status badge ticks from “Scheduled” to **Published**. Gentle 103% push. | **PUBLISHED**<br>Fri · 9:00 AM | Payoff: visibly confirm the publication result, using clearly fictional counts / UI. Badge becomes the final checkmark. |
| 00:21.70–00:24.00 | 2.30 s | Pull back to the four-state flow as linked cards: Check-in → Your notes → Approval → Published. The approval card remains brightest; first-frame shield shape subtly reappears for loop rhyme. | **YOUR IDEAS. YOUR APPROVAL. YOUR POST.**<br>Autoposter workflow | Clear close / cover-frame candidate. End on the approval check at the same visual scale and center position as the opening shield so it loops cleanly. |

## Required UI details

- The owner’s email is the only approval mechanism depicted. Show neither an automatic posting toggle nor a bypass route.
- Keep “DRAFT”, “Needs approval”, “Scheduled”, and “Published” as distinct, legible state chips—amber for waiting, blue for approved/scheduled, green only for confirmed publication.
- Emails, creator identity, content, engagement, and timestamps are fictional. Avoid LinkedIn’s exact UI, brand typography, or official assets.
- Title cards are maximum two lines and remain in the safe region. Each title arrives before or with its primary visual; no title should obscure an action field.

## Edit rhythm

Open fast (0–7.8 s), expand during the tangible draft and approval moment (7.8–14.6 s), then accelerate through scheduled-to-published payoff (14.6–21.7 s), with a confident final hold. This silent version uses visual beats only; no soundtrack or SFX is required.
