# Changelog

## v1 — Interactive walkthrough

- Built a fictional, animated email-to-approval-to-publication product demo.
- Uses a silent, high-contrast phone mock so the flow works with audio muted.
- Deliberately states that `approve 2 now` is the gate before publishing.
- Delivered as HTML after the available FFmpeg build could not render text overlays.
