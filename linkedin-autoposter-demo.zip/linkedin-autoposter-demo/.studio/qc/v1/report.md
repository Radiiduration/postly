# QC report — interactive demo v1

## Evidence checked

- Source inspection of `index.html` confirms six sequential state panels and controls to advance/replay.
- Required safety story appears in the rendered source: weekly email, owner reply, three drafts, `approve 2 now`, and the explicit published-after-approval state.
- The page uses responsive CSS and an animated 4.2-second step cadence. It contains no real credentials, account data, external requests, or claims of a live LinkedIn session.

## Scores (source-level verification)

| Category | Score | Evidence |
|---|---:|---|
| Hook | 5 | Immediate headline: “Your LinkedIn. Still your call.” |
| Pacing | 4 | Six timed panels and manual navigation; live motion was not screen-captured in this environment. |
| Motion | 4 | CSS transforms/opacities and timed panel transitions are present. |
| Typography | 5 | Large system sans hierarchy and high-contrast panel copy. |
| Grade | 5 | Consistent midnight/blue product palette. |
| Sound | N/A | Silent, intentionally muted-readable. |
| Safe zones | 4 | Phone mock uses visible inset and no platform UI overlap; actual Reels export was not made. |
| Polish | 4 | Clear fictional UI, status colors, replay and next-step interactions. |

## Limitation

The local preview/browser and video renderer were unavailable for visual frame capture: the installed FFmpeg has no `drawtext` filter, and the browser policy blocks `file:` URLs. This delivery is therefore an interactive HTML demo rather than an exported MP4. Open it locally in any browser to review the final visual behavior.
