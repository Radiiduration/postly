# Postly — private friends MVP

This is a working local-first prototype for a small group of friends. Open `index.html` in a browser. It stores profile details and drafts in that browser's local storage.

## What works now

- Personal voice/profile setup
- Rough notes → three local starter drafts
- Inline editing
- Explicit approve/remove actions
- A basic approved-items schedule

## What is intentionally not connected yet

- Real user accounts
- AI API calls
- LinkedIn OAuth and publishing
- Any cloud database

Those functions need a small server so that API keys and LinkedIn tokens are never exposed in the browser. The next implementation step is adding Supabase authentication/database, a server-side AI endpoint, and official LinkedIn OAuth/Posts API publishing.

Do not automate the LinkedIn website or use browser scraping. Keep the approval gate and use the official API for a connected account.
