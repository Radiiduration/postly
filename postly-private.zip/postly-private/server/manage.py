"""Private admin utility. Never share generated keys in chat or email."""
import secrets, sys
from app import db, init_db, iso

if len(sys.argv) != 3 or sys.argv[1] != "create-user":
    raise SystemExit("Usage: python manage.py create-user friend@example.com")
init_db(); user_id=secrets.token_urlsafe(12); api_key=secrets.token_urlsafe(32); c=db()
c.execute("INSERT INTO profiles (id,api_key,email,created_at) VALUES (?,?,?,?)",(user_id,api_key,sys.argv[2],iso()));c.commit();c.close()
print("Give this private key directly to the user:")
print(api_key)
print("OAuth connection URL (after deployment): /auth/linkedin/start?profile_id="+user_id)
