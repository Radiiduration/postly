"""Postly: small private email-first LinkedIn writing service.

Deploy behind HTTPS. It never drives linkedin.com; publishing uses LinkedIn OAuth
and the official Posts API after an explicit approval email from the owner.
"""
from __future__ import annotations

import email
import imaplib
import json
import os
import re
import secrets
import smtplib
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from email.utils import parseaddr
from functools import wraps
from pathlib import Path
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

import anthropic
import requests
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from flask import Flask, abort, jsonify, redirect, request
from itsdangerous import BadSignature, URLSafeTimedSerializer

load_dotenv()
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ["POSTLY_SECRET_KEY"]
DB = Path(os.getenv("DATABASE_PATH", "postly.db"))
MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5")
VERSION = os.getenv("LINKEDIN_VERSION", "202610")
BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")
F = Fernet(os.environ["TOKEN_ENCRYPTION_KEY"].encode())
OAUTH_STATE = URLSafeTimedSerializer(app.config["SECRET_KEY"], salt="linkedin-oauth")
TAG = re.compile(r"\[LP-([ib])-([0-9a-f-]+)\]")


def now() -> datetime: return datetime.now(timezone.utc)
def iso(dt: datetime | None = None) -> str: return (dt or now()).isoformat()
def db() -> sqlite3.Connection:
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c
def row(d: sqlite3.Row | None): return dict(d) if d else None


def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS profiles (
      id TEXT PRIMARY KEY, api_key TEXT UNIQUE NOT NULL, name TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
      audience TEXT NOT NULL DEFAULT '', facts TEXT NOT NULL DEFAULT '', topics TEXT NOT NULL DEFAULT '', timezone TEXT NOT NULL DEFAULT 'Australia/Melbourne',
      checkin_day INTEGER NOT NULL DEFAULT 1, checkin_time TEXT NOT NULL DEFAULT '09:00', next_checkin_at TEXT,
      linkedin_person_id TEXT, linkedin_token BLOB, linkedin_expiry TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS inputs (id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, body TEXT, used INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS batches (id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS items (
      id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, item_no INTEGER NOT NULL, title TEXT, pillar TEXT, topic TEXT,
      body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', publish_at TEXT, posted_at TEXT, linkedin_id TEXT, error TEXT
    );
    """)
    c.commit(); c.close()


@app.after_request
def extension_cors(response):
    origin = request.headers.get("Origin", "")
    if origin.startswith("chrome-extension://"):
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Postly-Key"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


def require_profile(fn):
    @wraps(fn)
    def inner(*args, **kwargs):
        key = request.headers.get("X-Postly-Key", "")
        p = row(db().execute("SELECT * FROM profiles WHERE api_key=?", (key,)).fetchone())
        if not p: return jsonify(error="invalid extension key"), 401
        return fn(p, *args, **kwargs)
    return inner


def send_email(to: str, subject: str, body: str):
    msg = EmailMessage(); msg["From"] = os.environ["GMAIL_ADDRESS"]; msg["To"] = to; msg["Subject"] = subject; msg.set_content(body)
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as s:
        s.login(os.environ["GMAIL_ADDRESS"], os.environ["GMAIL_APP_PASSWORD"]); s.send_message(msg)


def profile_prompt(p: dict) -> str:
    return f"""You write concise LinkedIn posts in first person for {p['name']}.
Only use real information in their profile and notes. Never invent achievements, jobs, employers, numbers, or personal experiences.
Avoid corporate filler. 600–1300 characters per post. Plain text; maximum three hashtags.
PROFILE: {p['audience']}\nFACTS: {p['facts']}\nTOPICS/OPINIONS: {p['topics']}"""


def make_drafts(p: dict, notes: str) -> list[dict]:
    client = anthropic.Anthropic()
    q = """Create exactly three distinct LinkedIn post drafts from these rough notes. Return only JSON:
{"items":[{"pillar":"...","topic":"...","title":"...","body":"..."}]}
ROUGH NOTES:\n""" + notes
    r = client.messages.create(model=MODEL, max_tokens=2600, system=profile_prompt(p), messages=[{"role":"user","content":q}])
    raw = "".join(x.text for x in r.content if getattr(x, "type", "") == "text")
    match = re.search(r"\{.*\}", raw, re.S)
    if not match: raise ValueError("AI did not return valid draft JSON")
    data = json.loads(match.group())
    return data["items"][:3]


def create_batch(p: dict, notes: str) -> str:
    drafts = make_drafts(p, notes); bid = str(uuid.uuid4()); c = db()
    c.execute("INSERT INTO batches VALUES (?,?,?)", (bid, p["id"], iso()))
    for n, x in enumerate(drafts, 1):
        c.execute("INSERT INTO items (id,batch_id,item_no,title,pillar,topic,body,status) VALUES (?,?,?,?,?,?,?,?)", (str(uuid.uuid4()), bid, n, x.get("title", f"Draft {n}"), x.get("pillar",""), x.get("topic",""), x["body"].strip()[:2900], "pending"))
    c.commit(); c.close(); return bid


def batch_email(p: dict, bid: str):
    c = db(); items = c.execute("SELECT * FROM items WHERE batch_id=? ORDER BY item_no", (bid,)).fetchall(); c.close()
    copy = []
    for x in items: copy.append(f"[{x['item_no']}] {x['title']}\n{'-'*48}\n{x['body']}\n")
    copy.append("Reply with one command per line:\n  approve\n  approve 2 now\n  edit 1: make it shorter\n  skip 3\n\nNothing posts until you explicitly approve it.")
    send_email(p["email"], f"[LP-b-{bid}] Your Postly drafts", "\n".join(copy))


def clean_reply(text: str) -> str:
    return re.split(r"\n(?:On .+wrote:|From:|> )", text, maxsplit=1, flags=re.I)[0].strip()


def parse_commands(text: str):
    out=[]
    for line in text.splitlines():
        line=line.strip(); m=re.match(r"^approve(?:\s+([123](?:\s+[123])*)|\s+all)?(?:\s+(now))?$",line,re.I)
        if m: out.append(("approve", (m.group(1) or "all").split(), bool(m.group(2)), None)); continue
        m=re.match(r"^skip(?:\s+([123](?:\s+[123])*)|\s+all)?$",line,re.I)
        if m: out.append(("skip", (m.group(1) or "all").split(), False, None)); continue
        m=re.match(r"^edit\s+([123])\s*:\s*(.+)$",line,re.I)
        if m: out.append(("edit",[m.group(1)],False,m.group(2)))
    return out


def next_weekday(p: dict) -> str:
    tz = ZoneInfo(p.get("timezone") or "Australia/Melbourne")
    h,m=map(int,p["checkin_time"].split(":")); t=now().astimezone(tz); d=(int(p["checkin_day"])-t.weekday())%7
    target=(t+timedelta(days=d)).replace(hour=h,minute=m,second=0,microsecond=0)
    if target<=t: target+=timedelta(days=7)
    return iso(target.astimezone(timezone.utc))


def send_checkin(p: dict):
    iid=str(uuid.uuid4()); c=db(); c.execute("INSERT INTO inputs VALUES (?,?,?,?,?)",(iid,p["id"],None,0,iso())); c.commit(); c.close()
    send_email(p["email"],f"[LP-i-{iid}] What is on your mind this week?","Reply with rough bullets: something you built, learned, noticed, or want to say. I will return drafts for approval.")


def handle_batch_reply(p: dict, bid: str, text: str):
    c=db(); items=c.execute("SELECT * FROM items WHERE batch_id=?",(bid,)).fetchall()
    if not items: return
    cmds=parse_commands(clean_reply(text)); notes=[]
    for action, ids, immediate, feedback in cmds:
        chosen=items if ids==["all"] else [x for x in items if str(x["item_no"]) in ids]
        for x in chosen:
            if action=="approve":
                when=iso() if immediate else iso(now()+timedelta(days=1))
                c.execute("UPDATE items SET status='approved',publish_at=?,error=NULL WHERE id=?",(when,x["id"])); notes.append(f"[{x['item_no']}] approved")
            elif action=="skip": c.execute("UPDATE items SET status='skipped' WHERE id=?",(x["id"],)); notes.append(f"[{x['item_no']}] skipped")
            elif action=="edit":
                prompt=f"Revise this post following the feedback. Return only the revised plain text.\nPOST:\n{x['body']}\nFEEDBACK:\n{feedback}"
                client=anthropic.Anthropic(); r=client.messages.create(model=MODEL,max_tokens=1600,system=profile_prompt(p),messages=[{"role":"user","content":prompt}])
                body="".join(z.text for z in r.content if getattr(z,"type","")=="text").strip()[:2900]
                c.execute("UPDATE items SET body=?,status='pending',publish_at=NULL WHERE id=?",(body,x["id"])); notes.append(f"[{x['item_no']}] revised; approve it again")
    c.commit(); c.close()
    if notes: send_email(p["email"], f"[LP-b-{bid}] Postly update", "\n".join(notes))


def poll_email():
    M=imaplib.IMAP4_SSL("imap.gmail.com"); M.login(os.environ["GMAIL_ADDRESS"],os.environ["GMAIL_APP_PASSWORD"]); M.select("INBOX")
    _,data=M.search(None,'(UNSEEN SUBJECT "[LP-")')
    for num in data[0].split():
        _,payload=M.fetch(num,"(BODY.PEEK[])"); msg=email.message_from_bytes(payload[0][1]); subject=msg.get("Subject",""); match=TAG.search(subject)
        body=msg.get_payload(decode=True).decode(msg.get_content_charset() or "utf-8",errors="replace") if not msg.is_multipart() else next((part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8",errors="replace") for part in msg.walk() if part.get_content_type()=="text/plain"),"")
        if not match: M.store(num,"+FLAGS","\\Seen"); continue
        kind,tag=match.groups(); c=db()
        if kind=="i": record=row(c.execute("SELECT * FROM inputs WHERE id=?",(tag,)).fetchone()); p=row(c.execute("SELECT * FROM profiles WHERE id=?",(record["profile_id"],)).fetchone()) if record else None
        else: record=row(c.execute("SELECT b.profile_id FROM batches b WHERE b.id=?",(tag,)).fetchone()); p=row(c.execute("SELECT * FROM profiles WHERE id=?",(record["profile_id"],)).fetchone()) if record else None
        c.close()
        if p and parseaddr(msg.get("From", ""))[1].lower()==p["email"].lower():
            if kind=="i":
                bid=create_batch(p,clean_reply(body)); batch_email(p,bid)
            else: handle_batch_reply(p,tag,body)
        M.store(num,"+FLAGS","\\Seen")
    M.logout()


def publish_due():
    c=db(); rows=c.execute("SELECT i.*,p.* FROM items i JOIN batches b ON b.id=i.batch_id JOIN profiles p ON p.id=b.profile_id WHERE i.status='approved' AND i.publish_at<=?",(iso(),)).fetchall()
    for x in rows:
        if not x["linkedin_token"]: continue
        token=F.decrypt(x["linkedin_token"]).decode(); body={"author":f"urn:li:person:{x['linkedin_person_id']}","commentary":x["body"],"visibility":"PUBLIC","distribution":{"feedDistribution":"MAIN_FEED","targetEntities":[],"thirdPartyDistributionChannels":[]},"lifecycleState":"PUBLISHED","isReshareDisabledByAuthor":False}
        r=requests.post("https://api.linkedin.com/rest/posts",headers={"Authorization":f"Bearer {token}","Linkedin-Version":VERSION,"X-Restli-Protocol-Version":"2.0.0","Content-Type":"application/json"},json=body,timeout=30)
        if r.status_code==201: c.execute("UPDATE items SET status='published',posted_at=?,linkedin_id=? WHERE id=?",(iso(),r.headers.get("x-restli-id",""),x["id"]))
        else: c.execute("UPDATE items SET status='failed',error=? WHERE id=?",(r.text[:400],x["id"]))
    c.commit();c.close()


@app.get("/health")
def health(): return {"ok":True}

@app.route("/api/profiles", methods=["OPTIONS"])
@app.route("/api/checkins/send", methods=["OPTIONS"])
def options_handler(): return ("", 204)

@app.post("/api/profiles")
@require_profile
def update_profile(p):
    payload=request.get_json(force=True); profile=payload.get("profile",payload); allowed=["name","email","audience","facts","topics","checkin_day","checkin_time","timezone"]
    profile = {**profile, "checkin_day": profile.get("checkin_day", profile.get("day", p["checkin_day"])), "checkin_time": profile.get("checkin_time", profile.get("time", p["checkin_time"]))}
    vals={k:profile[k] for k in allowed if k in profile}; vals["next_checkin_at"]=next_weekday({**p,**vals})
    c=db(); c.execute("UPDATE profiles SET "+",".join(f"{k}=?" for k in vals)+" WHERE id=?",(*vals.values(),p["id"]));c.commit();c.close(); return {"ok":True}

@app.post("/api/checkins/send")
@require_profile
def send_checkin_route(p):
    send_checkin(p)
    return {"ok":True}

@app.get("/api/connection/linkedin")
@require_profile
def linkedin_connection(p):
    if not BASE_URL: return {"error":"PUBLIC_BASE_URL is not configured"}, 503
    return {"url": BASE_URL+"/auth/linkedin/start?profile_id="+p["id"]}

@app.post("/api/jobs/run")
def run_jobs():
    if request.headers.get("X-Postly-Cron")!=os.environ["POSTLY_CRON_SECRET"]: abort(401)
    c=db(); due=[row(x) for x in c.execute("SELECT * FROM profiles WHERE next_checkin_at IS NOT NULL AND next_checkin_at<=?",(iso(),)).fetchall()]; c.close()
    for p in due:
        send_checkin(p); c=db(); c.execute("UPDATE profiles SET next_checkin_at=? WHERE id=?",(next_weekday(p),p["id"])); c.commit(); c.close()
    poll_email(); publish_due(); return {"ok":True,"checkins_sent":len(due)}

@app.get("/auth/linkedin/start")
def linkedin_start():
    pid=request.args.get("profile_id",""); p=row(db().execute("SELECT * FROM profiles WHERE id=?",(pid,)).fetchone())
    if not p or not BASE_URL: abort(400)
    state=OAUTH_STATE.dumps({"profile_id":pid,"nonce":secrets.token_urlsafe(16)})
    q=urlencode({"response_type":"code","client_id":os.environ["LINKEDIN_CLIENT_ID"],"redirect_uri":BASE_URL+"/auth/linkedin/callback","state":state,"scope":"openid profile w_member_social"})
    return redirect("https://www.linkedin.com/oauth/v2/authorization?"+q)

@app.get("/auth/linkedin/callback")
def linkedin_callback():
    try: pid=OAUTH_STATE.loads(request.args.get("state",""),max_age=600)["profile_id"]
    except (BadSignature, KeyError): abort(400)
    if not request.args.get("code"): abort(400)
    t=requests.post("https://www.linkedin.com/oauth/v2/accessToken",data={"grant_type":"authorization_code","code":request.args["code"],"redirect_uri":BASE_URL+"/auth/linkedin/callback","client_id":os.environ["LINKEDIN_CLIENT_ID"],"client_secret":os.environ["LINKEDIN_CLIENT_SECRET"]},timeout=30); t.raise_for_status(); data=t.json()
    info=requests.get("https://api.linkedin.com/v2/userinfo",headers={"Authorization":"Bearer "+data["access_token"]},timeout=30);info.raise_for_status()
    c=db();c.execute("UPDATE profiles SET linkedin_person_id=?,linkedin_token=?,linkedin_expiry=? WHERE id=?",(info.json()["sub"],F.encrypt(data["access_token"].encode()),iso(now()+timedelta(seconds=data.get("expires_in",5184000))),pid));c.commit();c.close()
    return "<h1>LinkedIn connected.</h1><p>You can close this tab and return to Postly.</p>"


if __name__=="__main__": init_db(); app.run(host="0.0.0.0",port=int(os.getenv("PORT","8000")))
