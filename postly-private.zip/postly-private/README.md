# Postly Private — complete email-first build

This package contains a Chrome extension and private Python server. It is designed for a small group of friends, not a public SaaS.

## User flow

1. Each friend loads the extension and saves their name, email, writing voice, and weekly check-in time.
2. The server emails a weekly prompt.
3. They reply with rough notes.
4. The server generates three drafts using Anthropic and sends them by email.
5. They reply `approve`, `approve 2 now`, `edit 1: ...`, or `skip 3`.
6. The server publishes only approved content through the official LinkedIn OAuth/Posts API.

The extension does not automate LinkedIn, scrape it, or inject into its pages.

## Deploy

1. Deploy `server/` to an HTTPS service such as Railway or Render using its Dockerfile. Give it persistent storage for `postly.db`.
2. Copy environment values from `server/.env.example`. Fill in Gmail App Password, Anthropic key, LinkedIn app credentials, and a public HTTPS URL.
3. In the LinkedIn Developer Portal add this redirect URL:

   `https://YOUR-SERVER/auth/linkedin/callback`

4. Run `python manage.py create-user friend@example.com` on the deployed service to issue each friend a private extension key.
5. Load `extension/` in Chrome at `chrome://extensions` → Developer mode → Load unpacked. In the extension settings, enter the server URL and the user’s private key.

## Run jobs

Call `POST /api/jobs/run` with header `X-Postly-Cron: YOUR_CRON_SECRET` every 15 minutes. That single task sends due check-ins, reads reply emails, makes drafts, and publishes approved content. You can use GitHub Actions, a host cron service, or an external scheduler.

## Required secrets

- `POSTLY_SECRET_KEY` and `POSTLY_CRON_SECRET`: long random values
- `TOKEN_ENCRYPTION_KEY`: a Fernet key (`Fernet.generate_key()`)
- Gmail address and App Password
- Anthropic key
- LinkedIn client ID and secret

Never put any of these values in the extension or commit them to Git.
